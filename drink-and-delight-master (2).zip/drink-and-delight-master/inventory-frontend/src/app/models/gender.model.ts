/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2020-11-05 03:11:26
 * @modify date 2020-11-05 03:11:26
 * @desc Gender
 */
export enum Gender {
  Male = 'Male',
  Female = 'Female',
}
