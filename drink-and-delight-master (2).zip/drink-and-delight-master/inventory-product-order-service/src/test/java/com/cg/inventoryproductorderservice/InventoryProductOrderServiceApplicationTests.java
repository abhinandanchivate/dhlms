package com.cg.inventoryproductorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryProductOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
