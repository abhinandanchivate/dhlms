package com.cg.inventoryproductorderservice.enums;

public enum MeasurementUnit {
  Kilogram, Litre
}
