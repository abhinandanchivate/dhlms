package com.cg.inventorystockmanagementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryStockManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
