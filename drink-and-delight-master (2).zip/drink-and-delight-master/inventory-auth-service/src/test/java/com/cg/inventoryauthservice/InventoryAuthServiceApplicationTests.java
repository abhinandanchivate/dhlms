package com.cg.inventoryauthservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
