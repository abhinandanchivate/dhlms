package com.cg.inventorysupplierservice.enums;

public enum MeasurementUnit {
  Kilogram, Litre
}
