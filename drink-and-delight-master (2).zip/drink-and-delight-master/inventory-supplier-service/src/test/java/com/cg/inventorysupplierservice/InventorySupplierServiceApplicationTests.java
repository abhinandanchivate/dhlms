/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2020-11-02 02:20:57
 * @modify date 2020-11-02 02:20:57
 * @desc Starting point sring  boot stest
 */
package com.cg.inventorysupplierservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class InventorySupplierServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
