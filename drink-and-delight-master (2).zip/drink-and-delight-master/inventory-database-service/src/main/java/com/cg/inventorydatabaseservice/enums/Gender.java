/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2020-09-19 18:33:16
 * @modify date 2020-09-19 18:33:16
 * @desc Gender Enum
 */
package com.cg.inventorydatabaseservice.enums;

public enum Gender {
  Male, Female
}
