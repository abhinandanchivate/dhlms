package com.cg.inventorydatabaseservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryDatabaseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
