/**
 * @author Abhinandan
 * @email Abhinandan
 * @create date 2020-11-05 03:11:26
 * @modify date 2020-11-05 03:11:26
 * @desc Gender
 */
export enum Gender {
  Male = "Male",
  Female = "Female",
}
